/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizza;

/**
 *
 * @author 20142bsi0070
 */
abstract class Pizza {

    public void bake() {
    }

    public void prepare() {
    }

    public void cut() {
    }

    public void box() {
    }
}
