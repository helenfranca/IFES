[![Build Status](https://travis-ci.org/paulossjunior/BDD.svg?branch=master)](https://travis-ci.org/paulossjunior/BDD)
# BDD

Exemplos de uso de BDD com  Java, Cucumber e Travis: Gambiarra aqui não!


